employee_name = "Mario"
age = "55"
title = "owner"

def details():
    print("Employee name is:  ", employee_name)
    print("Employee age is: ", age)
    print("Employee title is:  ", title)
